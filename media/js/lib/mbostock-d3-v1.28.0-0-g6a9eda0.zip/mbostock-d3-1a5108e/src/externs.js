// JavaScript built-ins.
var console,
    JSON;

// d3
var d3;
