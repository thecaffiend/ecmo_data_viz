d3.time = {};

var d3_time = Date;
