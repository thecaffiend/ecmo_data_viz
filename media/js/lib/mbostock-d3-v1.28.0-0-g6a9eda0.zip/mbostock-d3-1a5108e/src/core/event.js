d3.event = null;
