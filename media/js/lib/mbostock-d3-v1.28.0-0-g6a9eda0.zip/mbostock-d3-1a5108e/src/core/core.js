d3 = {version: "1.28.0"}; // semver
