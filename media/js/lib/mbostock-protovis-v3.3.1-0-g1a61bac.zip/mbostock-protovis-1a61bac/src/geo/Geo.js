/**
 * @ignore
 * @namespace
 */
pv.Geo = function() {};
